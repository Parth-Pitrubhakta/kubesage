"""SQL validator tests.

The interesting cases are at the bottom: documented weaknesses of the
blocklist approach, marked xfail so they stay visible rather than being
quietly forgotten.
"""

import pytest

from app.text2sql.validate import MAX_ROWS, SQLValidationError, validate_sql


class TestAllowed:
    def test_plain_select_passes(self):
        out = validate_sql("SELECT name, status FROM pods LIMIT 10")
        assert "SELECT" in out.upper()

    def test_missing_limit_gets_one(self):
        out = validate_sql("SELECT name FROM pods")
        assert "LIMIT" in out.upper()
        assert str(MAX_ROWS) in out

    def test_excessive_limit_is_capped(self):
        out = validate_sql("SELECT name FROM pods LIMIT 999999")
        assert str(MAX_ROWS) in out
        assert "999999" not in out

    def test_join_across_allowed_tables(self):
        out = validate_sql(
            "SELECT p.name, e.reason FROM pods p "
            "JOIN events e ON e.pod_name = p.name LIMIT 20"
        )
        assert "JOIN" in out.upper()

    def test_aggregate_passes(self):
        out = validate_sql(
            "SELECT namespace, COUNT(*) FROM pods GROUP BY namespace LIMIT 50"
        )
        assert "COUNT" in out.upper()


class TestBlocked:
    @pytest.mark.parametrize("sql", [
        "DELETE FROM pods",
        "DROP TABLE pods",
        "UPDATE pods SET status = 'Running'",
        "INSERT INTO pods (name) VALUES ('x')",
        "TRUNCATE TABLE events",
        "ALTER TABLE pods ADD COLUMN x INT",
        "CREATE TABLE evil (id INT)",
    ])
    def test_write_operations_rejected(self, sql):
        with pytest.raises(SQLValidationError):
            validate_sql(sql)

    def test_stacked_statements_rejected(self):
        with pytest.raises(SQLValidationError, match="one statement"):
            validate_sql("SELECT name FROM pods; DROP TABLE pods")

    def test_unknown_table_rejected(self):
        with pytest.raises(SQLValidationError, match="not permitted"):
            validate_sql("SELECT * FROM pg_shadow")

    def test_system_catalog_rejected(self):
        with pytest.raises(SQLValidationError):
            validate_sql("SELECT usename, passwd FROM pg_user")

    def test_unparseable_rejected(self):
        with pytest.raises(SQLValidationError):
            validate_sql("SELECT FROM WHERE ((((")

    def test_comment_hidden_write_rejected(self):
        # sqlglot parses rather than pattern-matches, so comments don't hide this.
        with pytest.raises(SQLValidationError):
            validate_sql("/* harmless */ DELETE FROM pods")

    def test_cte_wrapping_write_rejected(self):
        with pytest.raises(SQLValidationError):
            validate_sql(
                "WITH x AS (DELETE FROM pods RETURNING *) SELECT * FROM x"
            )

    def test_nested_subquery_tables_are_checked(self):
        # sqlglot's find_all traverses into subqueries, so the allowlist
        # applies at any depth rather than only to the outer FROM.
        with pytest.raises(SQLValidationError, match="not permitted"):
            validate_sql("SELECT * FROM (SELECT * FROM pg_authid) AS x LIMIT 10")


class TestKnownWeaknesses:
    """Documented gaps. These are why the human approval gate exists."""

    @pytest.mark.xfail(reason="no cost bound; a cartesian join passes validation")
    def test_expensive_join_should_be_bounded(self):
        with pytest.raises(SQLValidationError):
            validate_sql("SELECT * FROM pods, nodes, events, deployments LIMIT 500")
