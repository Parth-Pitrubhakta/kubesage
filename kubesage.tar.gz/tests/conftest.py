"""Test fixtures.

Settings are validated at import time, so the environment has to be populated
before any app module loads. Setting it here rather than in CI config means
the suite runs identically on a laptop and in Actions.
"""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key")
os.environ.setdefault("QDRANT_URL", "http://localhost:6333")
os.environ.setdefault("POSTGRES_URL", "postgresql://test:test@localhost:5432/test")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("JWT_SECRET", "test-secret")

import pytest  # noqa: E402


@pytest.fixture
def sample_docs():
    return [
        {"id": "d1", "text": "Containers exceeding memory limits are OOMKilled.",
         "title": "Resource Management", "score": 0.91},
        {"id": "d2", "text": "A readiness probe gates traffic to a pod.",
         "title": "Probes", "score": 0.84},
    ]


@pytest.fixture
def rag_state(sample_docs):
    return {
        "query": "why are my pods OOMKilled",
        "user_id": "u-test",
        "route": "rag",
        "documents": sample_docs,
        "regeneration_count": 0,
    }
