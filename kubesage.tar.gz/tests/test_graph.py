"""Graph traversal tests.

These exercise the conditional edges directly rather than running the whole
graph, which keeps them fast and free of network calls. The edge functions
are where the routing logic actually lives.
"""

import pytest

from app.graph.edges import (
    branch_on_approval,
    branch_on_intent,
    branch_on_reflection,
    branch_on_relevance,
)


class TestIntentBranch:
    @pytest.mark.parametrize("route,expected", [
        ("rag", "rag"),
        ("sql", "sql"),
        ("hybrid", "hybrid"),
    ])
    def test_routes_map_directly(self, route, expected):
        assert branch_on_intent({"route": route}) == expected

    def test_missing_route_defaults_to_rag(self):
        assert branch_on_intent({}) == "rag"


class TestCragBranch:
    def test_low_relevance_triggers_web_fallback(self):
        assert branch_on_relevance({"crag_score": 0.3}) == "fallback"

    def test_high_relevance_proceeds(self):
        assert branch_on_relevance({"crag_score": 0.95}) == "proceed"

    def test_missing_score_proceeds(self):
        # Grader failure shouldn't force an unnecessary web search.
        assert branch_on_relevance({}) == "proceed"


class TestApprovalBranch:
    def test_approved_runs_sql(self):
        assert branch_on_approval({"sql_approved": True}) == "approved"

    def test_rejected_skips_execution(self):
        assert branch_on_approval({"sql_approved": False}) == "rejected"

    def test_absent_approval_is_treated_as_rejection(self):
        # Fail closed: no explicit approval means no execution.
        assert branch_on_approval({}) == "rejected"


class TestSelfRagCycle:
    def test_grounded_answer_accepted(self):
        state = {"self_rag_score": 0.9, "regeneration_count": 0}
        assert branch_on_reflection(state) == "accept"

    def test_ungrounded_answer_regenerates(self):
        state = {"self_rag_score": 0.4, "regeneration_count": 0}
        assert branch_on_reflection(state) == "regenerate"

    def test_cycle_terminates_at_retry_cap(self):
        # The loop must be bounded or a persistently ungrounded answer
        # spins forever, burning tokens.
        state = {"self_rag_score": 0.1, "regeneration_count": 2}
        assert branch_on_reflection(state) == "accept"

    def test_exactly_at_threshold_accepts(self):
        state = {"self_rag_score": 0.8, "regeneration_count": 0}
        assert branch_on_reflection(state) == "accept"
