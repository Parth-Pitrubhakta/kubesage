"""RRF is pure and deterministic, so it can be tested exactly."""

import pytest

from app.retrieval.fusion import reciprocal_rank_fusion


def doc(i):
    return {"id": f"d{i}", "text": f"document {i}"}


def test_document_in_both_lists_outranks_one_appearing_once():
    list_a = [doc(1), doc(2), doc(3)]
    list_b = [doc(3), doc(4), doc(5)]

    fused = reciprocal_rank_fusion([list_a, list_b], k=60)

    # d3 is rank 3 in A and rank 1 in B; nothing else appears twice.
    assert fused[0]["id"] == "d3"


def test_scores_match_the_formula():
    fused = reciprocal_rank_fusion([[doc(1), doc(2)]], k=60)

    assert fused[0]["rrf_score"] == pytest.approx(1 / 61)
    assert fused[1]["rrf_score"] == pytest.approx(1 / 62)


def test_empty_input_returns_empty():
    assert reciprocal_rank_fusion([]) == []
    assert reciprocal_rank_fusion([[], []]) == []


def test_single_list_preserves_order():
    docs = [doc(i) for i in range(5)]
    fused = reciprocal_rank_fusion([docs])
    assert [d["id"] for d in fused] == [d["id"] for d in docs]


def test_k_dampens_top_rank_advantage():
    # Both lists agree on the ordering, so d1 leads d2 in each. A large k
    # should shrink the score gap between them.
    lists = [[doc(1), doc(2)], [doc(1), doc(2)]]

    small_k = reciprocal_rank_fusion(lists, k=1)
    large_k = reciprocal_rank_fusion(lists, k=1000)

    gap_small = small_k[0]["rrf_score"] - small_k[1]["rrf_score"]
    gap_large = large_k[0]["rrf_score"] - large_k[1]["rrf_score"]

    assert gap_large < gap_small


def test_originals_are_not_mutated():
    original = doc(1)
    reciprocal_rank_fusion([[original]])
    assert "rrf_score" not in original
