"""Evaluation harness.

Runs the golden set against a live instance and reports routing accuracy,
retrieval precision, grounding, and latency. Numbers here are what go in the
README — measure, don't estimate.

Usage:
    python -m eval.run --dataset eval/golden_set.json --url http://localhost:8000
"""

from __future__ import annotations

import argparse
import asyncio
import json
import statistics
from dataclasses import dataclass, field
from pathlib import Path

import httpx


@dataclass
class CaseResult:
    id: str
    routed_correctly: bool | None = None
    blocked_as_expected: bool | None = None
    mentions_hit: float | None = None
    self_rag_score: float | None = None
    latency_ms: int | None = None
    error: str | None = None


@dataclass
class Report:
    results: list[CaseResult] = field(default_factory=list)

    def _collect(self, attr):
        return [getattr(r, attr) for r in self.results
                if getattr(r, attr) is not None]

    def summary(self) -> dict:
        routing = self._collect("routed_correctly")
        blocking = self._collect("blocked_as_expected")
        mentions = self._collect("mentions_hit")
        grounding = self._collect("self_rag_score")
        latencies = self._collect("latency_ms")

        def pct(xs):
            return round(100 * sum(xs) / len(xs), 1) if xs else None

        return {
            "cases": len(self.results),
            "errors": len([r for r in self.results if r.error]),
            "routing_accuracy_pct": pct(routing),
            "guardrail_accuracy_pct": pct(blocking),
            "keyword_coverage_pct": (
                round(100 * statistics.mean(mentions), 1) if mentions else None
            ),
            "mean_grounding_score": (
                round(statistics.mean(grounding), 3) if grounding else None
            ),
            "p50_latency_ms": (
                int(statistics.median(latencies)) if latencies else None
            ),
            "p95_latency_ms": (
                int(sorted(latencies)[int(0.95 * len(latencies)) - 1])
                if len(latencies) >= 2 else None
            ),
        }


async def run_case(client: httpx.AsyncClient, case: dict, token: str) -> CaseResult:
    result = CaseResult(id=case["id"])
    headers = {"Authorization": f"Bearer {token}"}

    try:
        resp = await client.post(
            "/api/v1/query", json={"query": case["query"]},
            headers=headers, timeout=90.0,
        )
        resp.raise_for_status()
        body = resp.json()
    except Exception as exc:
        result.error = str(exc)
        return result

    if case.get("expect_blocked"):
        result.blocked_as_expected = body["status"] == "blocked"
        return result

    result.blocked_as_expected = body["status"] != "blocked"

    if case.get("expected_route"):
        result.routed_correctly = body.get("route") == case["expected_route"]

    # SQL cases suspend for approval — auto-approve so the run completes.
    if body["status"] == "pending_approval":
        resp = await client.post(
            f"/api/v1/approve/{body['thread_id']}",
            json={"approved": True}, headers=headers, timeout=90.0,
        )
        body = resp.json()

    answer = (body.get("answer") or "").lower()
    if case.get("must_mention"):
        hits = sum(1 for kw in case["must_mention"] if kw.lower() in answer)
        result.mentions_hit = hits / len(case["must_mention"])

    result.self_rag_score = body.get("self_rag_score")
    result.latency_ms = body.get("latency_ms")
    return result


async def main(dataset: Path, url: str, token: str) -> None:
    cases = json.loads(dataset.read_text())
    report = Report()

    async with httpx.AsyncClient(base_url=url) as client:
        for case in cases:
            print(f"  running {case['id']} ...", flush=True)
            report.results.append(await run_case(client, case, token))

    print("\n--- per case ---")
    for r in report.results:
        status = "ERROR" if r.error else "ok"
        print(f"{r.id:16} {status:6} route={r.routed_correctly} "
              f"grounding={r.self_rag_score} {r.latency_ms}ms")

    print("\n--- summary ---")
    for k, v in report.summary().items():
        print(f"{k:26} {v}")

    Path("eval/last_run.json").write_text(
        json.dumps({"summary": report.summary(),
                    "results": [vars(r) for r in report.results]}, indent=2)
    )
    print("\nwritten to eval/last_run.json")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=Path, default=Path("eval/golden_set.json"))
    ap.add_argument("--url", default="http://localhost:8000")
    ap.add_argument("--token", default="", help="JWT bearer token")
    args = ap.parse_args()
    asyncio.run(main(args.dataset, args.url, args.token))
