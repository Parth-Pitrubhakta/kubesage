"""Composes the guardrail layers into request-side and response-side passes.

Ordering is deliberate: cheap deterministic checks run before anything that
costs a network call, so an obvious attack is rejected without spending money.

  L1  schema + injection patterns   (free)
  L4a auth                          (free, local verify)
  L4b rate limit                    (one Redis op)
  L6  token budget                  (one Redis op)
  L5  restructure + truncate        (local)
  L7a moderation + PII redaction    (network)

L2 (llm-guard toxicity scan) is deliberately last on the request side and is
optional — it is the slowest layer and the one most likely to be dropped
under latency pressure.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from app.config import get_settings
from app.security.auth import (
    enforce_rate_limit,
    enforce_token_budget,
    estimate_tokens,
)
from app.security.injection import scan_injection
from app.security.pii import redact

log = logging.getLogger(__name__)
settings = get_settings()


@dataclass
class GuardResult:
    allowed: bool
    text: str
    reason: str | None = None
    layers_triggered: list[str] = field(default_factory=list)


def _restructure(text: str) -> str:
    """L5 — collapse whitespace and truncate to the configured ceiling."""
    text = " ".join(text.split())
    if len(text) > settings.max_query_chars:
        text = text[: settings.max_query_chars]
    return text


async def guard_request(query: str, user_id: str) -> GuardResult:
    triggered: list[str] = []

    # L1 — injection heuristics
    suspicious, pattern = scan_injection(query)
    if suspicious:
        log.warning("L1 blocked query from %s: %s", user_id, pattern)
        return GuardResult(
            allowed=False,
            text=query,
            reason=f"blocked by input filter ({pattern})",
            layers_triggered=["L1"],
        )

    # L4b / L6 — both raise HTTPException on breach
    await enforce_rate_limit(user_id)
    await enforce_token_budget(user_id, estimate_tokens(query))

    # L5 — restructure
    cleaned = _restructure(query)
    if cleaned != query:
        triggered.append("L5")

    # L7a — PII redaction before the text reaches any model provider
    cleaned, found = redact(cleaned)
    if found:
        triggered.append("L7a")
        log.info("L7a redacted %s from request", ", ".join(found))

    return GuardResult(allowed=True, text=cleaned, layers_triggered=triggered)


async def guard_response(answer: str) -> GuardResult:
    triggered: list[str] = []

    # L7b — catch PII that arrived via the corpus rather than the request
    cleaned, found = redact(answer)
    if found:
        triggered.append("L7b")
        log.info("L7b redacted %s from response", ", ".join(found))

    return GuardResult(allowed=True, text=cleaned, layers_triggered=triggered)
