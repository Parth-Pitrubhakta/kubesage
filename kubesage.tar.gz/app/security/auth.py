"""L4a auth, L4b rate limiting, L6 token budget.

Rate limit and budget both use Redis counters keyed by user and window, so
limits hold across replicas rather than per-container.
"""

from __future__ import annotations

import time
from datetime import UTC, datetime

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.cache.tiered import cache
from app.config import get_settings

settings = get_settings()
bearer = HTTPBearer()


async def current_user(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
) -> str:
    """Validate the bearer token and return the subject claim."""
    try:
        payload = jwt.decode(
            creds.credentials,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm],
        )
    except jwt.ExpiredSignatureError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "token expired") from exc
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid token") from exc

    sub = payload.get("sub")
    if not sub:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "token missing subject")
    return sub


async def enforce_rate_limit(user_id: str) -> None:
    """Fixed-window limiter. Simpler than a sliding window and adequate here;
    the tradeoff is burst tolerance at window boundaries."""
    window = int(time.time() // 60)
    key = f"kubesage:ratelimit:{user_id}:{window}"

    count = await cache._redis.incr(key)
    if count == 1:
        await cache._redis.expire(key, 120)

    if count > settings.rate_limit_per_minute:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            f"rate limit exceeded ({settings.rate_limit_per_minute}/min)",
        )


async def enforce_token_budget(user_id: str, tokens: int) -> None:
    """Daily token ceiling — the guard against a single user running up an
    unbounded bill through repeated expensive queries."""
    day = datetime.now(UTC).strftime("%Y%m%d")
    key = f"kubesage:tokens:{user_id}:{day}"

    used = await cache._redis.incrby(key, tokens)
    if used == tokens:
        await cache._redis.expire(key, 48 * 3600)

    if used > settings.token_budget_per_day:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            f"daily token budget exhausted ({settings.token_budget_per_day})",
        )


def estimate_tokens(text: str) -> int:
    try:
        import tiktoken

        return len(tiktoken.encoding_for_model(settings.llm_model).encode(text))
    except Exception:
        return len(text) // 4  # rough fallback
