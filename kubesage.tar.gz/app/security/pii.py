"""L7a/L7b — PII redaction, applied to both request and response.

Request-side redaction keeps secrets out of the LLM provider's logs.
Response-side redaction catches PII that leaked in through the corpus —
a config dump or incident report pasted into documentation, for instance.

The patterns below cover common infrastructure secrets. For anything
regulatory, swap in a purpose-built engine (Presidio, llm-guard) rather than
trusting regex.
"""

from __future__ import annotations

import re

REDACTION_PATTERNS: list[tuple[str, re.Pattern, str]] = [
    ("email", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b"), "[EMAIL]"),
    ("ipv4", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"), "[IP]"),
    ("aws_key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"), "[AWS_KEY]"),
    ("bearer", re.compile(r"\bBearer\s+[A-Za-z0-9._\-]{20,}"), "Bearer [TOKEN]"),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9._\-]{20,}\b"), "[JWT]"),
    ("private_key", re.compile(
        r"-----BEGIN[\s\w]*PRIVATE KEY-----[\s\S]*?-----END[\s\w]*PRIVATE KEY-----"),
     "[PRIVATE_KEY]"),
    ("k8s_secret", re.compile(
        r"(?i)\b(password|passwd|secret|api[_-]?key|token)\s*[:=]\s*\S{6,}"),
     r"\1: [REDACTED]"),
]


def redact(text: str) -> tuple[str, list[str]]:
    """Redact known-sensitive patterns. Returns (clean_text, kinds_found)."""
    found: list[str] = []
    for name, pattern, replacement in REDACTION_PATTERNS:
        text, n = pattern.subn(replacement, text)
        if n:
            found.append(name)
    return text, found
