"""Thin wrapper over the OpenAI client.

Everything that talks to a model goes through here so retries, structured
output parsing and token accounting live in exactly one place.
"""

from __future__ import annotations

import logging
from typing import TypeVar

from openai import AsyncOpenAI
from pydantic import BaseModel
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import get_settings

log = logging.getLogger(__name__)
T = TypeVar("T", bound=BaseModel)

_settings = get_settings()
_client = AsyncOpenAI(api_key=_settings.openai_api_key)


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
async def complete(
    prompt: str,
    system: str | None = None,
    temperature: float = 0.0,
    max_tokens: int = 1024,
) -> str:
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    resp = await _client.chat.completions.create(
        model=_settings.llm_model,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return resp.choices[0].message.content or ""


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
async def complete_structured(
    prompt: str,
    schema: type[T],
    system: str | None = None,
    temperature: float = 0.0,
) -> T:
    """Parse the model response into `schema`.

    This is L9 in miniature: if the model returns something that doesn't fit
    the schema, tenacity retries rather than letting malformed data through.
    """
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    resp = await _client.beta.chat.completions.parse(
        model=_settings.llm_model,
        messages=messages,
        temperature=temperature,
        response_format=schema,
    )
    parsed = resp.choices[0].message.parsed
    if parsed is None:
        raise ValueError(f"model returned no parseable {schema.__name__}")
    return parsed


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
async def embed(texts: list[str]) -> list[list[float]]:
    resp = await _client.embeddings.create(
        model=_settings.embedding_model, input=texts
    )
    return [d.embedding for d in resp.data]
