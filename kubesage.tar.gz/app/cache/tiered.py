"""Five-tier Redis cache.

Each tier has its own TTL because the things being cached go stale at very
different rates: a query embedding is deterministic for the life of a model
version, while a SQL result over live cluster data is stale in minutes.
"""

from __future__ import annotations

import hashlib
import json
import logging
from enum import Enum
from typing import Any

import redis.asyncio as redis

from app.config import get_settings

log = logging.getLogger(__name__)


class Tier(str, Enum):
    EMBEDDING = "embedding"
    INTENT = "intent"
    SQL_GEN = "sql_gen"
    SQL_RESULT = "sql_result"
    RAG_ANSWER = "rag_answer"


TTL_SECONDS: dict[Tier, int] = {
    Tier.EMBEDDING: 7 * 24 * 3600,
    Tier.INTENT: 24 * 3600,
    Tier.SQL_GEN: 24 * 3600,
    Tier.SQL_RESULT: 15 * 60,
    Tier.RAG_ANSWER: 3600,
}


class TieredCache:
    def __init__(self, url: str | None = None):
        settings = get_settings()
        self._redis = redis.from_url(url or settings.redis_url, decode_responses=True)

    @staticmethod
    def _key(tier: Tier, payload: str) -> str:
        norm = " ".join(payload.lower().split())
        digest = hashlib.sha256(norm.encode()).hexdigest()[:32]
        return f"kubesage:{tier.value}:{digest}"

    async def get(self, tier: Tier, payload: str) -> Any | None:
        try:
            raw = await self._redis.get(self._key(tier, payload))
        except Exception as exc:  # cache must never take the request down
            log.warning("cache read failed on %s: %s", tier.value, exc)
            return None
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            log.warning("corrupt cache entry on %s, discarding", tier.value)
            return None

    async def set(self, tier: Tier, payload: str, value: Any) -> None:
        try:
            await self._redis.setex(
                self._key(tier, payload), TTL_SECONDS[tier], json.dumps(value)
            )
        except Exception as exc:
            log.warning("cache write failed on %s: %s", tier.value, exc)

    async def stats(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for tier in Tier:
            pattern = f"kubesage:{tier.value}:*"
            counts[tier.value] = len([k async for k in self._redis.scan_iter(pattern)])
        return counts

    async def close(self) -> None:
        await self._redis.aclose()


cache = TieredCache()
