"""Schema-aware SQL generation and execution."""

from __future__ import annotations

import logging
from typing import Any

import asyncpg

from app.cache.tiered import Tier, cache
from app.config import get_settings
from app.llm import complete

log = logging.getLogger(__name__)
settings = get_settings()

SCHEMA_DDL = """
pods(name TEXT, namespace TEXT, node TEXT, status TEXT,
     restart_count INT, memory_limit_mi INT, created_at TIMESTAMPTZ)
nodes(name TEXT, status TEXT, cpu_capacity INT, memory_capacity_mi INT,
      kubelet_version TEXT)
deployments(name TEXT, namespace TEXT, replicas INT, available_replicas INT,
            updated_at TIMESTAMPTZ)
events(id BIGINT, pod_name TEXT, namespace TEXT, reason TEXT,
       message TEXT, count INT, occurred_at TIMESTAMPTZ)
incidents(id BIGINT, cluster TEXT, severity TEXT, summary TEXT,
          opened_at TIMESTAMPTZ, resolved_at TIMESTAMPTZ)
"""

_SYSTEM = f"""You write PostgreSQL SELECT queries against a Kubernetes
operations database. Schema:

{SCHEMA_DDL}

Rules:
- SELECT only. Never write, alter or drop.
- Query only the tables listed above.
- Always include a LIMIT.
- Prefer explicit column lists over SELECT *.
- Return only the SQL. No markdown fences, no explanation.
"""

_pool: asyncpg.Pool | None = None


async def get_pool() -> asyncpg.Pool:
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(
            settings.postgres_url, min_size=2, max_size=10
        )
    return _pool


async def generate_sql(question: str) -> str:
    cached = await cache.get(Tier.SQL_GEN, question)
    if cached is not None:
        log.info("SQL generation cache hit")
        return cached

    sql = await complete(question, system=_SYSTEM, temperature=0.0)
    sql = sql.strip().removeprefix("```sql").removeprefix("```").removesuffix("```")
    sql = sql.strip()

    await cache.set(Tier.SQL_GEN, question, sql)
    return sql


async def execute_sql(sql: str) -> list[dict[str, Any]]:
    """Execute validated SQL. Caller must have run validate_sql first."""
    cached = await cache.get(Tier.SQL_RESULT, sql)
    if cached is not None:
        log.info("SQL result cache hit")
        return cached

    pool = await get_pool()
    async with pool.acquire() as conn:
        # Belt and braces: even a validator bypass hits a read-only transaction.
        async with conn.transaction(readonly=True):
            rows = await conn.fetch(sql)

    result = [dict(r) for r in rows]
    await cache.set(Tier.SQL_RESULT, sql, _jsonable(result))
    return result


def _jsonable(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for row in rows:
        out.append({k: (v.isoformat() if hasattr(v, "isoformat") else v)
                    for k, v in row.items()})
    return out


def format_rows(rows: list[dict[str, Any]], max_rows: int = 50) -> str:
    """Render rows as context for the answer-generation prompt."""
    if not rows:
        return "The query returned no rows."

    shown = rows[:max_rows]
    headers = list(shown[0].keys())
    lines = [" | ".join(headers), "-" * 40]
    lines.extend(" | ".join(str(r.get(h, "")) for h in headers) for r in shown)

    if len(rows) > max_rows:
        lines.append(f"... {len(rows) - max_rows} further rows omitted")
    return "\n".join(lines)
