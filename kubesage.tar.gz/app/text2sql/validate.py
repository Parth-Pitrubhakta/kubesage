"""SQL validation before execution.

KNOWN LIMITATION — read this before trusting it.

This is a blocklist: it enumerates what is forbidden and permits the rest.
Blocklists lose to allowlists, because they can only reject attacks somebody
already thought of. Parsing with sqlglot rather than regex closes the easy
evasions (comment splitting, unusual whitespace, string-literal smuggling),
but the structural weakness remains.

The correct production fix is defence at the database boundary, not the
application: connect as a role with SELECT-only grants on an explicit set of
tables. Then a validator bypass fails at the engine. This module is the
second line, not the first.

The human approval gate exists precisely because this layer is fallible.
"""

from __future__ import annotations

import logging

import sqlglot
from sqlglot import expressions as exp

log = logging.getLogger(__name__)

FORBIDDEN = {
    exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create,
    exp.Alter, exp.TruncateTable, exp.Grant,
}

ALLOWED_TABLES = {
    "pods", "nodes", "deployments", "events",
    "incidents", "clusters", "restarts",
}

MAX_ROWS = 500


class SQLValidationError(Exception):
    pass


def validate_sql(sql: str) -> str:
    """Parse, check, and return SQL with a row limit applied.

    Raises SQLValidationError on anything that isn't a bounded read.
    """
    try:
        parsed = sqlglot.parse(sql, read="postgres")
    except Exception as exc:
        raise SQLValidationError(f"unparseable SQL: {exc}") from exc

    statements = [s for s in parsed if s is not None]
    if len(statements) != 1:
        raise SQLValidationError(
            f"expected exactly one statement, got {len(statements)}"
        )

    stmt = statements[0]

    if not isinstance(stmt, exp.Select):
        raise SQLValidationError(f"only SELECT permitted, got {type(stmt).__name__}")

    for node_type in FORBIDDEN:
        if list(stmt.find_all(node_type)):
            raise SQLValidationError(f"forbidden operation: {node_type.__name__}")

    for table in stmt.find_all(exp.Table):
        name = (table.name or "").lower()
        if name and name not in ALLOWED_TABLES:
            raise SQLValidationError(f"table not permitted: {name}")

    # Bound the result set so a broad query can't return the whole table.
    limit = stmt.args.get("limit")
    if limit is None:
        stmt = stmt.limit(MAX_ROWS)
    else:
        try:
            if int(limit.expression.this) > MAX_ROWS:
                stmt = stmt.limit(MAX_ROWS)
        except (AttributeError, ValueError):
            stmt = stmt.limit(MAX_ROWS)

    return stmt.sql(dialect="postgres")
