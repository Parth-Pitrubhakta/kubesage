"""Centralised configuration, loaded from environment."""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # --- LLM ---
    openai_api_key: str
    llm_model: str = "gpt-4o"
    embedding_model: str = "text-embedding-3-small"
    embedding_dim: int = 1536

    # --- Vector store ---
    qdrant_url: str
    qdrant_api_key: str | None = None
    qdrant_collection: str = "kubesage"

    # --- Relational ---
    postgres_url: str

    # --- Cache ---
    redis_url: str

    # --- Auth ---
    jwt_secret: str
    jwt_algorithm: str = "HS256"

    # --- Optional web fallback ---
    tavily_api_key: str | None = None

    # --- Tunables ---
    crag_threshold: float = 0.7
    self_rag_threshold: float = 0.8
    self_rag_max_retries: int = 2
    hyde_num_hypotheses: int = 3
    retrieval_top_k: int = 20
    rerank_top_k: int = 5
    rrf_k: int = 60

    # --- Limits ---
    rate_limit_per_minute: int = 20
    token_budget_per_day: int = 100_000
    max_query_chars: int = 2000

    model_config = SettingsConfigDict(
        env_file=".env", case_sensitive=False, extra="ignore"
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
