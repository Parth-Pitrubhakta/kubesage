"""Request and response schemas. L1 and L9 of the guardrail pipeline both
lean on these — untrusted input is parsed into them on the way in, and
generated output is validated against them on the way out."""

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class Route(str, Enum):
    RAG = "rag"
    SQL = "sql"
    HYBRID = "hybrid"


class QueryRequest(BaseModel):
    query: str = Field(min_length=3, max_length=2000)
    thread_id: str | None = None

    @field_validator("query")
    @classmethod
    def strip_and_check(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("query must not be blank")
        return v


class Source(BaseModel):
    title: str
    score: float
    url: str | None = None


class QueryResponse(BaseModel):
    status: Literal["complete", "pending_approval", "blocked"]
    answer: str | None = None
    route: Route | None = None
    sources: list[Source] = []
    pending_sql: str | None = None
    thread_id: str | None = None
    cache_hit: bool = False
    self_rag_score: float | None = None
    latency_ms: int | None = None
    block_reason: str | None = None


class ApprovalRequest(BaseModel):
    approved: bool
    reason: str | None = None


class GradeResult(BaseModel):
    """Structured output for the CRAG relevance grader."""

    score: float = Field(ge=0.0, le=1.0)
    reasoning: str


class ReflectResult(BaseModel):
    """Structured output for the Self-RAG reflection step."""

    score: float = Field(ge=0.0, le=1.0)
    grounded: bool
    reasoning: str
