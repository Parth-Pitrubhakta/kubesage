"""Graph state.

Everything the graph needs lives here rather than in closures, because the
Postgres checkpointer serialises this dict at every node boundary. That is
what lets a run pause at the SQL approval gate and resume minutes later in a
different process.
"""

from __future__ import annotations

from typing import Any, TypedDict


class GraphState(TypedDict, total=False):
    # Input
    query: str
    user_id: str

    # Routing
    route: str  # "rag" | "sql" | "hybrid"

    # RAG branch
    hypotheses: list[str]
    documents: list[dict[str, Any]]
    crag_score: float
    used_web_fallback: bool
    context: str

    # SQL branch
    generated_sql: str
    sql_approved: bool
    sql_rejection_reason: str | None
    sql_rows: list[dict[str, Any]]
    sql_context: str

    # Generation
    answer: str
    self_rag_score: float
    regeneration_count: int

    # Bookkeeping
    cache_hit: bool
    errors: list[str]
