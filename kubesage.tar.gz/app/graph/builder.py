"""Graph assembly.

The conditional edges are the reason this is a graph and not a function call
chain. Three of them create real cycles or branches that a linear pipeline
cannot express:

  route_intent   → three-way branch on classified intent
  grade_documents → web fallback when local retrieval is weak (CRAG)
  reflect        → back to generation when the answer isn't grounded (Self-RAG)

The last is a genuine cycle, bounded by self_rag_max_retries so a
persistently ungrounded answer terminates instead of looping.
"""

from __future__ import annotations

import logging

from langgraph.graph import END, START, StateGraph

from app.config import get_settings
from app.graph import nodes
from app.graph.edges import (
    after_context,
    branch_on_approval,
    branch_on_intent,
    branch_on_reflection,
    branch_on_relevance,
)
from app.graph.state import GraphState

log = logging.getLogger(__name__)
settings = get_settings()


# --------------------------------------------------------------------------
# Assembly
# --------------------------------------------------------------------------


def build_graph(checkpointer=None):
    g = StateGraph(GraphState)

    g.add_node("route_intent", nodes.route_intent)

    # RAG branch
    g.add_node("expand_query", nodes.expand_query)
    g.add_node("retrieve", nodes.retrieve)
    g.add_node("rerank_documents", nodes.rerank_documents)
    g.add_node("grade_documents", nodes.grade_documents)
    g.add_node("search_web", nodes.search_web)
    g.add_node("build_context", nodes.build_context)

    # SQL branch
    g.add_node("write_sql", nodes.write_sql)
    g.add_node("await_approval", nodes.await_approval)
    g.add_node("run_sql", nodes.run_sql)

    # Generation
    g.add_node("generate_answer", nodes.generate_answer)
    g.add_node("reflect", nodes.reflect)

    g.add_edge(START, "route_intent")
    g.add_conditional_edges(
        "route_intent",
        branch_on_intent,
        {"rag": "expand_query", "sql": "write_sql", "hybrid": "expand_query"},
    )

    # --- RAG path ---
    g.add_edge("expand_query", "retrieve")
    g.add_edge("retrieve", "rerank_documents")
    g.add_edge("rerank_documents", "grade_documents")
    g.add_conditional_edges(
        "grade_documents",
        branch_on_relevance,
        {"fallback": "search_web", "proceed": "build_context"},
    )
    g.add_edge("search_web", "build_context")

    # Hybrid queries collect documents first, then fall through to SQL.
    g.add_conditional_edges(
        "build_context",
        after_context,
        {"sql": "write_sql", "generate": "generate_answer"},
    )

    # --- SQL path ---
    g.add_edge("write_sql", "await_approval")
    g.add_conditional_edges(
        "await_approval",
        branch_on_approval,
        {"approved": "run_sql", "rejected": "generate_answer"},
    )
    g.add_edge("run_sql", "generate_answer")

    # --- Generation and the Self-RAG cycle ---
    g.add_edge("generate_answer", "reflect")
    g.add_conditional_edges(
        "reflect",
        branch_on_reflection,
        {"regenerate": "generate_answer", "accept": END},
    )

    return g.compile(checkpointer=checkpointer)


async def build_graph_with_postgres():
    """Production graph, checkpointed to Postgres so interrupts survive
    restarts and can be resumed from any replica.

    The psycopg import is deferred so build_graph() above stays importable
    without a Postgres driver — tests exercise the topology in-memory.
    """
    from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

    async with AsyncPostgresSaver.from_conn_string(settings.postgres_url) as saver:
        await saver.setup()
        yield build_graph(checkpointer=saver)
