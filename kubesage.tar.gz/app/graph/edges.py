"""Conditional edge functions.

These live apart from builder.py deliberately. They are pure — state in,
route name out, no I/O — which is what makes the graph's control flow
testable without a running LangGraph, a database, or an LLM. Keeping them
free of framework imports is the whole point.

Three of these create branches a linear pipeline cannot express:

  branch_on_intent     — three-way split on classified intent
  branch_on_relevance  — CRAG: correct course to web search on weak retrieval
  branch_on_reflection — Self-RAG: a genuine cycle back to generation
"""

from __future__ import annotations

import logging

from app.config import get_settings
from app.graph.state import GraphState

log = logging.getLogger(__name__)
settings = get_settings()


def branch_on_intent(state: GraphState) -> str:
    route = state.get("route", "rag")
    if route == "sql":
        return "sql"
    if route == "hybrid":
        return "hybrid"
    return "rag"


def branch_on_relevance(state: GraphState) -> str:
    """CRAG. Below threshold, reach for the web instead of answering from
    weak context. Defaults to proceeding — a grader outage shouldn't force
    an unnecessary web search."""
    score = state.get("crag_score", 1.0)
    if score < settings.crag_threshold:
        log.info("CRAG %.2f < %.2f — falling back to web",
                 score, settings.crag_threshold)
        return "fallback"
    return "proceed"


def branch_on_approval(state: GraphState) -> str:
    """Fails closed: anything other than explicit approval skips execution."""
    return "approved" if state.get("sql_approved") else "rejected"


def branch_on_reflection(state: GraphState) -> str:
    """Self-RAG. Regenerate ungrounded answers, but bound the loop — a
    persistently ungrounded answer would otherwise spin forever burning
    tokens."""
    score = state.get("self_rag_score", 1.0)
    attempts = state.get("regeneration_count", 0)

    if score >= settings.self_rag_threshold:
        return "accept"
    if attempts >= settings.self_rag_max_retries:
        log.info("self-RAG %.2f still below threshold after %d attempts; accepting",
                 score, attempts)
        return "accept"

    log.info("self-RAG %.2f < %.2f — regenerating (attempt %d)",
             score, settings.self_rag_threshold, attempts + 1)
    return "regenerate"


def after_context(state: GraphState) -> str:
    """Hybrid queries gather documents first, then continue into the SQL
    branch; pure RAG queries go straight to generation."""
    return "sql" if state.get("route") == "hybrid" else "generate"
