"""FastAPI entrypoint."""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, status
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.types import Command

from app.cache.tiered import cache
from app.config import get_settings
from app.graph.builder import build_graph
from app.models import ApprovalRequest, QueryRequest, QueryResponse, Source
from app.security.auth import current_user
from app.security.pipeline import guard_request, guard_response

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
log = logging.getLogger(__name__)
settings = get_settings()

_state: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    saver_cm = AsyncPostgresSaver.from_conn_string(settings.postgres_url)
    saver = await saver_cm.__aenter__()
    await saver.setup()
    _state["saver_cm"] = saver_cm
    _state["graph"] = build_graph(checkpointer=saver)
    log.info("graph compiled with Postgres checkpointer")
    yield
    await saver_cm.__aexit__(None, None, None)
    await cache.close()


app = FastAPI(
    title="KubeSage",
    description="Enterprise Advanced RAG for Kubernetes Operations",
    version="1.0.0",
    lifespan=lifespan,
)


def _sources(state: dict) -> list[Source]:
    out = []
    for d in state.get("documents", [])[: settings.rerank_top_k]:
        out.append(Source(
            title=d.get("title", "untitled"),
            score=float(d.get("rerank_score", d.get("score", 0.0))),
            url=d.get("url"),
        ))
    return out


@app.post("/api/v1/query", response_model=QueryResponse)
async def query(req: QueryRequest, user_id: str = Depends(current_user)):
    started = time.perf_counter()

    guard = await guard_request(req.query, user_id)
    if not guard.allowed:
        return QueryResponse(status="blocked", block_reason=guard.reason)

    thread_id = req.thread_id or str(uuid.uuid4())
    config = {"configurable": {"thread_id": thread_id}}

    result = await _state["graph"].ainvoke(
        {"query": guard.text, "user_id": user_id, "regeneration_count": 0},
        config=config,
    )

    # An interrupt leaves __interrupt__ on the result rather than an answer.
    if "__interrupt__" in result:
        payload = result["__interrupt__"][0].value
        return QueryResponse(
            status="pending_approval",
            pending_sql=payload.get("sql"),
            thread_id=thread_id,
            route=result.get("route"),
        )

    checked = await guard_response(result.get("answer", ""))
    elapsed = int((time.perf_counter() - started) * 1000)

    return QueryResponse(
        status="complete",
        answer=checked.text,
        route=result.get("route"),
        sources=_sources(result),
        thread_id=thread_id,
        cache_hit=result.get("cache_hit", False),
        self_rag_score=result.get("self_rag_score"),
        latency_ms=elapsed,
    )


@app.post("/api/v1/approve/{thread_id}", response_model=QueryResponse)
async def approve(
    thread_id: str,
    req: ApprovalRequest,
    user_id: str = Depends(current_user),
):
    """Resume a graph suspended at the SQL approval gate."""
    started = time.perf_counter()
    config = {"configurable": {"thread_id": thread_id}}

    snapshot = await _state["graph"].aget_state(config)
    if not snapshot.next:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            "no suspended run for that thread_id",
        )

    result = await _state["graph"].ainvoke(
        Command(resume={"approved": req.approved, "reason": req.reason}),
        config=config,
    )

    checked = await guard_response(result.get("answer", ""))
    elapsed = int((time.perf_counter() - started) * 1000)

    return QueryResponse(
        status="complete",
        answer=checked.text,
        route=result.get("route"),
        sources=_sources(result),
        thread_id=thread_id,
        self_rag_score=result.get("self_rag_score"),
        latency_ms=elapsed,
    )


@app.get("/api/v1/health")
async def health():
    checks = {"api": "ok"}
    try:
        await cache._redis.ping()
        checks["redis"] = "ok"
    except Exception as exc:
        checks["redis"] = f"error: {exc}"
    return {"status": "ok" if all(v == "ok" for v in checks.values())
            else "degraded", "checks": checks}


@app.get("/api/v1/metrics")
async def metrics(user_id: str = Depends(current_user)):
    return {"cache_keys": await cache.stats()}
