"""Reciprocal Rank Fusion.

Dense cosine similarity and BM25 produce scores on incompatible scales, so
they cannot be combined by weighted sum without normalisation that is itself
arbitrary. RRF ignores the scores entirely and fuses on rank position:

    score(d) = sum over lists of 1 / (k + rank(d))

k dampens the influence of the top positions; k=60 is the value from the
original Cormack et al. paper and is a reasonable default.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

DEFAULT_K = 60  # Cormack et al.; kept local so this module stays pure


def reciprocal_rank_fusion(
    ranked_lists: list[list[dict[str, Any]]],
    k: int | None = None,
    id_field: str = "id",
) -> list[dict[str, Any]]:
    """Fuse several ranked lists of documents into one.

    Args:
        ranked_lists: each inner list ordered best-first.
        k: RRF damping constant.
        id_field: key used to identify the same document across lists.

    Returns:
        Documents ordered by fused score, each with an added `rrf_score`.
    """
    k = k or DEFAULT_K
    scores: dict[Any, float] = defaultdict(float)
    docs: dict[Any, dict[str, Any]] = {}

    for ranked in ranked_lists:
        for rank, doc in enumerate(ranked, start=1):
            doc_id = doc[id_field]
            scores[doc_id] += 1.0 / (k + rank)
            docs.setdefault(doc_id, doc)

    fused = []
    for doc_id, score in sorted(scores.items(), key=lambda kv: kv[1], reverse=True):
        doc = dict(docs[doc_id])
        doc["rrf_score"] = score
        fused.append(doc)
    return fused
