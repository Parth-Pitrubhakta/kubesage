"""HyDE — Hypothetical Document Embeddings.

Operators phrase questions very differently from how documentation states
facts ("why is my pod dying" vs "containers exceeding their memory limit are
terminated"). Embedding the question directly means matching a question
against answers. Generating a hypothetical answer first and embedding *that*
puts query and corpus in the same register.
"""

from __future__ import annotations

import asyncio
import logging

from app.config import get_settings
from app.llm import complete

log = logging.getLogger(__name__)
settings = get_settings()

_SYSTEM = (
    "You are a Kubernetes documentation writer. Given an operator's question, "
    "write a short passage as it would appear in official documentation. "
    "Two to three sentences. State facts directly; do not address the reader "
    "or acknowledge the question."
)


async def generate_hypotheses(query: str, n: int | None = None) -> list[str]:
    n = n or settings.hyde_num_hypotheses
    tasks = [
        complete(query, system=_SYSTEM, temperature=0.7, max_tokens=200)
        for _ in range(n)
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    hypotheses = [r for r in results if isinstance(r, str) and r.strip()]
    if not hypotheses:
        # Degrade to the raw query rather than failing the request.
        log.warning("HyDE produced nothing usable; falling back to raw query")
        return [query]
    return hypotheses
