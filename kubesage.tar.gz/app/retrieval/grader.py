"""CRAG — Corrective RAG.

Naive RAG answers from whatever came back, however irrelevant. This grades
the retrieved context first; below threshold the system reaches for web
search instead of confabulating from weak chunks.
"""

from __future__ import annotations

import logging
from typing import Any

from app.config import get_settings
from app.llm import complete_structured
from app.models import GradeResult

log = logging.getLogger(__name__)
settings = get_settings()

_SYSTEM = (
    "You grade whether retrieved context can answer a question. "
    "Score 1.0 if it fully answers it, 0.5 if partially, 0.0 if unrelated. "
    "Judge only relevance to the question — not writing quality or completeness "
    "of the documentation itself."
)


async def grade_relevance(query: str, docs: list[dict[str, Any]]) -> float:
    if not docs:
        return 0.0

    context = "\n\n---\n\n".join(d["text"][:1000] for d in docs[:5])
    prompt = f"Question:\n{query}\n\nRetrieved context:\n{context}"

    try:
        result: GradeResult = await complete_structured(
            prompt, schema=GradeResult, system=_SYSTEM
        )
    except Exception as exc:
        # Fail open: a grader outage shouldn't block an otherwise good answer.
        log.error("grader failed, assuming relevant: %s", exc)
        return 1.0

    log.info("CRAG score %.2f — %s", result.score, result.reasoning[:120])
    return result.score


async def web_fallback(query: str) -> list[dict[str, Any]]:
    """Search the web when local retrieval scores below threshold."""
    if not settings.tavily_api_key:
        log.warning("web fallback requested but TAVILY_API_KEY is unset")
        return []

    try:
        from tavily import AsyncTavilyClient

        client = AsyncTavilyClient(api_key=settings.tavily_api_key)
        res = await client.search(
            query=f"kubernetes {query}", max_results=5, search_depth="advanced"
        )
    except Exception as exc:
        log.error("web fallback failed: %s", exc)
        return []

    return [
        {
            "id": f"web:{i}",
            "text": r.get("content", ""),
            "title": r.get("title", "web result"),
            "url": r.get("url"),
            "score": r.get("score", 0.0),
            "source": "web",
        }
        for i, r in enumerate(res.get("results", []))
    ]
