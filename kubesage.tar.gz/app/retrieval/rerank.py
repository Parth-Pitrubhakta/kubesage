"""Cross-encoder reranking.

Retrieval uses a bi-encoder: query and document are embedded separately, so
the model never sees them together. That is what makes it fast enough to
search 10k chunks, and also what limits its precision. A cross-encoder scores
the pair jointly — far more accurate, far too slow for the whole corpus.

So: bi-encoder for recall over everything, cross-encoder for precision over
the top ~20.
"""

from __future__ import annotations

import asyncio
import logging
from functools import lru_cache
from typing import Any

from app.config import get_settings

log = logging.getLogger(__name__)
settings = get_settings()

_MODEL_NAME = "cross-encoder/ms-marco-MiniLM-L-6-v2"


@lru_cache(maxsize=1)
def _get_model():
    from sentence_transformers import CrossEncoder

    log.info("loading cross-encoder %s", _MODEL_NAME)
    return CrossEncoder(_MODEL_NAME, max_length=512)


def _score_sync(query: str, docs: list[dict[str, Any]]) -> list[float]:
    model = _get_model()
    pairs = [(query, d["text"]) for d in docs]
    return [float(s) for s in model.predict(pairs)]


async def rerank(
    query: str, docs: list[dict[str, Any]], top_k: int | None = None
) -> list[dict[str, Any]]:
    top_k = top_k or settings.rerank_top_k
    if not docs:
        return []

    try:
        # CrossEncoder.predict is blocking; keep the event loop free.
        scores = await asyncio.to_thread(_score_sync, query, docs)
    except Exception as exc:
        # Fusion order is a reasonable fallback if the reranker is unavailable.
        log.error("rerank failed, falling back to RRF order: %s", exc)
        return docs[:top_k]

    for doc, score in zip(docs, scores, strict=True):
        doc["rerank_score"] = score

    ranked = sorted(docs, key=lambda d: d["rerank_score"], reverse=True)
    return ranked[:top_k]
