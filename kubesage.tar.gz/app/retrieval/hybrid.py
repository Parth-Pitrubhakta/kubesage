"""Hybrid retrieval: dense vectors for meaning, sparse for exact tokens.

Dense embeddings blur near-identical identifiers together — `CrashLoopBackOff`
and `ImagePullBackOff` land close in embedding space despite meaning entirely
different things. BM25 keeps them apart. Running both and fusing the ranks
recovers what either alone would miss.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from qdrant_client import AsyncQdrantClient, models

from app.cache.tiered import Tier, cache
from app.config import get_settings
from app.llm import embed
from app.retrieval.fusion import reciprocal_rank_fusion

log = logging.getLogger(__name__)
settings = get_settings()

_client = AsyncQdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_api_key)


async def _embed_cached(text: str) -> list[float]:
    hit = await cache.get(Tier.EMBEDDING, text)
    if hit is not None:
        return hit
    vector = (await embed([text]))[0]
    await cache.set(Tier.EMBEDDING, text, vector)
    return vector


def _to_doc(point: Any) -> dict[str, Any]:
    payload = point.payload or {}
    return {
        "id": str(point.id),
        "text": payload.get("text", ""),
        "title": payload.get("title", "untitled"),
        "url": payload.get("url"),
        "score": float(point.score),
    }


async def _dense_search(vector: list[float], top_k: int) -> list[dict[str, Any]]:
    res = await _client.query_points(
        collection_name=settings.qdrant_collection,
        query=vector,
        using="dense",
        limit=top_k,
        with_payload=True,
    )
    return [_to_doc(p) for p in res.points]


async def _sparse_search(query: str, top_k: int) -> list[dict[str, Any]]:
    """BM25 over the sparse vector index.

    Assumes the collection was created with a sparse vector named "sparse"
    and a server-side BM25 model — see scripts/ingest.py.
    """
    res = await _client.query_points(
        collection_name=settings.qdrant_collection,
        query=models.Document(text=query, model="Qdrant/bm25"),
        using="sparse",
        limit=top_k,
        with_payload=True,
    )
    return [_to_doc(p) for p in res.points]


async def hybrid_search(
    query: str,
    hypotheses: list[str] | None = None,
    top_k: int | None = None,
) -> list[dict[str, Any]]:
    """Run dense search over each HyDE hypothesis plus sparse search over the
    raw query, then fuse every resulting ranked list with RRF."""
    top_k = top_k or settings.retrieval_top_k
    texts = hypotheses or [query]

    try:
        vectors = await asyncio.gather(*[_embed_cached(t) for t in texts])
        dense_lists = await asyncio.gather(
            *[_dense_search(v, top_k) for v in vectors]
        )
    except Exception as exc:
        log.error("dense retrieval failed: %s", exc)
        dense_lists = []

    try:
        sparse_list = await _sparse_search(query, top_k)
    except Exception as exc:
        log.error("sparse retrieval failed: %s", exc)
        sparse_list = []

    all_lists = [lst for lst in [*dense_lists, sparse_list] if lst]
    if not all_lists:
        return []
    return reciprocal_rank_fusion(all_lists)
