-- Kubernetes operations schema. Seeded into Postgres by docker-compose.
-- Mirrors SCHEMA_DDL in app/text2sql/generate.py; keep the two in sync.

CREATE TABLE IF NOT EXISTS nodes (
    name              TEXT PRIMARY KEY,
    status            TEXT NOT NULL,
    cpu_capacity      INT,
    memory_capacity_mi INT,
    kubelet_version   TEXT
);

CREATE TABLE IF NOT EXISTS pods (
    name            TEXT NOT NULL,
    namespace       TEXT NOT NULL,
    node            TEXT REFERENCES nodes(name),
    status          TEXT NOT NULL,
    restart_count   INT DEFAULT 0,
    memory_limit_mi INT,
    created_at      TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (namespace, name)
);

CREATE TABLE IF NOT EXISTS deployments (
    name               TEXT NOT NULL,
    namespace          TEXT NOT NULL,
    replicas           INT,
    available_replicas INT,
    updated_at         TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (namespace, name)
);

CREATE TABLE IF NOT EXISTS events (
    id          BIGSERIAL PRIMARY KEY,
    pod_name    TEXT,
    namespace   TEXT,
    reason      TEXT,
    message     TEXT,
    count       INT DEFAULT 1,
    occurred_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS incidents (
    id          BIGSERIAL PRIMARY KEY,
    cluster     TEXT,
    severity    TEXT,
    summary     TEXT,
    opened_at   TIMESTAMPTZ DEFAULT now(),
    resolved_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pods_restarts ON pods(restart_count DESC);
CREATE INDEX IF NOT EXISTS idx_events_occurred ON events(occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_events_reason ON events(reason);

-- Read-only role. This is the defence that actually holds if the SQL
-- validator is bypassed — grant nothing but SELECT on these tables.
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'kubesage_reader') THEN
        CREATE ROLE kubesage_reader LOGIN PASSWORD 'reader';
    END IF;
END
$$;

GRANT CONNECT ON DATABASE kubesage TO kubesage_reader;
GRANT USAGE ON SCHEMA public TO kubesage_reader;
GRANT SELECT ON pods, nodes, deployments, events, incidents TO kubesage_reader;

-- Sample data
INSERT INTO nodes VALUES
    ('node-1', 'Ready', 8, 32768, 'v1.29.4'),
    ('node-2', 'Ready', 8, 32768, 'v1.29.4'),
    ('node-3', 'NotReady', 4, 16384, 'v1.28.9')
ON CONFLICT DO NOTHING;

INSERT INTO pods (name, namespace, node, status, restart_count, memory_limit_mi) VALUES
    ('checkout-7d9f', 'prod', 'node-1', 'CrashLoopBackOff', 14, 512),
    ('api-gateway-2a1b', 'prod', 'node-2', 'Running', 0, 1024),
    ('worker-5c3d', 'prod', 'node-1', 'OOMKilled', 7, 256),
    ('cache-warm-9e2f', 'staging', 'node-3', 'Pending', 0, 512)
ON CONFLICT DO NOTHING;

INSERT INTO events (pod_name, namespace, reason, message, count) VALUES
    ('checkout-7d9f', 'prod', 'BackOff', 'Back-off restarting failed container', 14),
    ('worker-5c3d', 'prod', 'OOMKilling', 'Container exceeded memory limit', 7)
ON CONFLICT DO NOTHING;
