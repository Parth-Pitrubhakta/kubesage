"""Build the Qdrant hybrid collection from a documentation corpus.

Chunking is header-aware rather than fixed-width: Kubernetes docs are heavily
sectioned, and splitting mid-section strands a code block from the prose that
explains it. Sections are split further only when they exceed the size cap.

Usage:
    python -m scripts.ingest --source data/k8s-docs/ [--recreate]
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import re
import uuid
from pathlib import Path

from qdrant_client import AsyncQdrantClient, models

from app.config import get_settings
from app.llm import embed

logging.basicConfig(level=logging.INFO, format="%(levelname)s — %(message)s")
log = logging.getLogger("ingest")
settings = get_settings()

CHUNK_CHARS = 2000
OVERLAP_CHARS = 200
BATCH_SIZE = 50


def chunk_markdown(text: str, title: str) -> list[dict]:
    """Split on markdown headers, then subdivide oversized sections."""
    sections = re.split(r"\n(?=#{1,3}\s)", text)
    chunks: list[dict] = []

    for section in sections:
        section = section.strip()
        if len(section) < 50:
            continue

        header_match = re.match(r"#{1,3}\s+(.+)", section)
        header = header_match.group(1) if header_match else title

        if len(section) <= CHUNK_CHARS:
            chunks.append({"text": section, "title": f"{title} — {header}"})
            continue

        start = 0
        part = 1
        while start < len(section):
            end = start + CHUNK_CHARS
            piece = section[start:end]
            # Prefer to break on a paragraph boundary.
            if end < len(section):
                boundary = piece.rfind("\n\n")
                if boundary > CHUNK_CHARS // 2:
                    piece = piece[:boundary]
                    end = start + boundary
            chunks.append({
                "text": piece.strip(),
                "title": f"{title} — {header} ({part})",
            })
            start = max(end - OVERLAP_CHARS, end)
            part += 1

    return chunks


async def ensure_collection(client: AsyncQdrantClient, recreate: bool) -> None:
    exists = await client.collection_exists(settings.qdrant_collection)
    if exists and not recreate:
        log.info("collection %s exists", settings.qdrant_collection)
        return
    if exists:
        log.warning("dropping collection %s", settings.qdrant_collection)
        await client.delete_collection(settings.qdrant_collection)

    await client.create_collection(
        collection_name=settings.qdrant_collection,
        vectors_config={
            "dense": models.VectorParams(
                size=settings.embedding_dim, distance=models.Distance.COSINE
            )
        },
        sparse_vectors_config={
            "sparse": models.SparseVectorParams(
                modifier=models.Modifier.IDF  # BM25-style scoring
            )
        },
    )
    log.info("created collection %s", settings.qdrant_collection)


async def main(source: Path, recreate: bool) -> None:
    client = AsyncQdrantClient(
        url=settings.qdrant_url, api_key=settings.qdrant_api_key
    )
    await ensure_collection(client, recreate)

    files = sorted(source.rglob("*.md"))
    if not files:
        log.error("no markdown files under %s", source)
        return
    log.info("found %d files", len(files))

    all_chunks: list[dict] = []
    for path in files:
        text = path.read_text(encoding="utf-8", errors="ignore")
        all_chunks.extend(chunk_markdown(text, path.stem.replace("-", " ").title()))

    log.info("produced %d chunks", len(all_chunks))

    for i in range(0, len(all_chunks), BATCH_SIZE):
        batch = all_chunks[i : i + BATCH_SIZE]
        vectors = await embed([c["text"] for c in batch])

        points = [
            models.PointStruct(
                id=str(uuid.uuid4()),
                vector={
                    "dense": vec,
                    "sparse": models.Document(text=c["text"], model="Qdrant/bm25"),
                },
                payload={"text": c["text"], "title": c["title"]},
            )
            for c, vec in zip(batch, vectors, strict=True)
        ]
        await client.upsert(settings.qdrant_collection, points=points)
        log.info("upserted %d/%d", min(i + BATCH_SIZE, len(all_chunks)),
                 len(all_chunks))

    log.info("ingestion complete")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=Path, required=True)
    ap.add_argument("--recreate", action="store_true")
    args = ap.parse_args()
    asyncio.run(main(args.source, args.recreate))
